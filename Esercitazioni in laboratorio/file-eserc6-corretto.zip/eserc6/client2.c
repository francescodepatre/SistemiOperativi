#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define MAXBUF     8192

int main(int argc, char * argv[])
{
  int client_socket,fd,portno;
  int retcode,letti;
  struct sockaddr_in  server;
  struct hostent *server_addr;
  char message[MAXBUF];
  char *nomehost,*filename;

  if(argc != 4) 
  {
    printf("Usage:\n%s nomefile nomehost portno\n",argv[0]);
    exit(1);
  }
  filename = argv[1];
  nomehost = argv[2];
  printf("Client (%d): fase di inizializzazione\n",getpid());
  client_socket = socket(AF_INET,SOCK_STREAM,0);
  if(client_socket == -1) 
  { 
    perror("aprendo la socket del cliente"); 
    exit(2);
  }

  portno = atoi(argv[3]);
  server.sin_family = AF_INET;
  server.sin_port   = htons(portno);

	
  
	server_addr = gethostbyname(argv[2]);
	if (server_addr == NULL) {
        fprintf(stderr,"ERRORE: host sconosciuto\n");
        exit(3);
    }
    
    memcpy((char *)&server.sin_addr,(char *)server_addr->h_addr,server_addr->h_length);
   
  
  
  retcode = connect(client_socket,
		 (struct sockaddr *)&server,
		 sizeof(server));
  if(retcode == -1) 
  { 
    perror("Errore connect");
    exit(4); 
  }
  fd = open(filename,O_RDONLY);
  if(fd == -1) 
  {
    perror("aprendo il file");
    exit(5);
  }
  do {
    letti = read(fd,message,MAXBUF);
    if(letti > 0) { /* solo se la lettura ha avuto buon fine */
      retcode = write(client_socket,message,letti);
      if(retcode == -1) 
      { 
	perror("scrivendo il messaggio"); 
	exit(6); 
      }
    }
  } while (letti > 0);
  close(fd);
  close(client_socket);
  exit(0);
}
