typedef struct _RICHIESTA_MSG 
{
  int req;
} RICHIESTA_MSG;

typedef struct _RISPOSTA_MSG 
{
  int answ; 
} RISPOSTA_MSG;

