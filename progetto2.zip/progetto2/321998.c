/*
    Author Luca Coloretti 321998
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>

#define terminal "xterm"


/*creo una matrice di pipe: una per ogni comando (al massimo 4 pipe)*/
int piped[4][2];

/*definisco una struct contenente il nome del comando e il pid del processo che la esegue*/
/*questo mi permette di riconoscere in base al pid quale comando è stato interrotto o terminato*/
typedef struct _cmd
{
    char *comd;
    int pid;
} command;

/*eseguo il comando*/
void execute_cmd(char *cmd, int cmd_id)
{	
	command tm_cmd;
    int child_pid, pid;

	/*creo un processo figlio che eseguirà il comando*/
	pid = fork();
    if(pid < 0)
	{
		perror("Fork error");
		exit(3);
	}
	else if (pid == 0)
	/*codice del figlio*/
	{	
        child_pid = getpid();

        /*assegno alla pipe corrispondente al comando attuale il pid del processo attuale, che eseguirà il comando*/
        read(piped[cmd_id][0], &tm_cmd, sizeof(tm_cmd));
        tm_cmd.pid = child_pid;
        write(piped[cmd_id][1], &tm_cmd, sizeof(tm_cmd));
        printf("Cmd: %s assigned to process with pid #%d\n", cmd, child_pid);

        /*Creo il comando "cmd; read"*/
        strcat(cmd, ";read");       
		char *args[] = {terminal,"-e", cmd, (char *)0};

        /*eseguo la exec che apre il comando in un ambiente esterno (un terminale)*/
		execvp(terminal, args);

        /*questa parte di codice viene eseguita solo se la exec fallisce*/
		perror("Terminal error");
		exit(4);
	}	
}


/*handler del segnale sigchld*/
void sigchld_handler(int signo, siginfo_t *sip, void *notused)
{
    int status;
    int killed_pid = sip->si_pid;   //recupero il pid grazie a siginfo
    
    status = 0;
    if (killed_pid == waitpid (killed_pid, &status, WNOHANG))
    {
        /*controlliamo se il processo è terminato normalmente o a causa di un segnale esterno*/
        /*se WIFSIGNALED è diverso da zero allora il processo è terminato a causa di segnali esterni*/
        if (WIFSIGNALED(status) != 0)   
        {
            printf("Il processo %d è stato terminato da un segnale.\n", killed_pid);
        }
        /*WIFSIGNALED è uguale a zero, quindi il processo è terminato normalmente (quindi dall'utente)*/
        else
        {
            char *cmd;
            command get_cmd, tmp_cmd;
            for (int i = 0; i < 3; i++)
            {
                read(piped[i][0], &get_cmd, sizeof(get_cmd));
                tmp_cmd = get_cmd;
                write(piped[i][1], &get_cmd, sizeof(tmp_cmd));
                if (tmp_cmd.pid == killed_pid)
                {
                    cmd = tmp_cmd.comd;
                    execute_cmd(cmd, i);
                }
            }
        } 
    }
}


int main(int argc, char *argv[])
{
    char *cmds[argc - 1];
    char *cmd;
    int cmd_n = 0;
    command as_cmd;
    int main_pid;

    /*gestione affidabile dei segnali*/
    struct sigaction sig;
    sig.sa_sigaction = sigchld_handler;  //è necessario utilizzare.sa_sigaction
	sigemptyset(&sig.sa_mask);
	sig.sa_flags = SA_SIGINFO;  //con siginfo posso sapere il pid del processo figlio che invia sigchld
    sigaction(SIGCHLD, &sig, NULL); //sigchld viene inviato da un figlio al padre quando termina

    if (argc < 3 || argc > 5)
    {
        printf("Use: %s <cmd1> <cmd2> ... to max of 4 commands\n", argv[0]);
        exit(1);
    }

    /*creo una lista contenente tutti comandi*/
    for (int i = 1; i < argc; i++)
    {
        cmd = argv[i];
        cmds[cmd_n] = cmd;
        cmd_n += 1;
    }

    /*la matrice di pipe che tiene traccia delle assegnazioni dei comandi ai processi tramite la struct 'command'*/
    for (size_t i = 0; i < cmd_n; i++)
    {
        if (pipe(piped[i]) < 0)
        {
            perror("creating pipe");
            exit(2);
        }
        else
        {
            as_cmd.comd = cmds[i];
            write(piped[i][1], &as_cmd, sizeof(as_cmd));
        }
        
    }
    

    main_pid = getpid();
    printf("Pid programma #%d\n", main_pid);
    printf("Premere invio per uscire dal programma\n");

    /*esegui i vari comandi*/
    for (int i = 0; i < cmd_n; i++)
    {
        cmd = cmds[i];
        execute_cmd(cmd, i);
    }
    
    /*aggiungo un ciclo while che chiude il programma solo dopo aver premuto invio, così da dar modo
    di verificare la "riapertura dei terminali a processo padre ancora attivo"*/
	while(getchar() != '\n'){};

	exit(0);

}
