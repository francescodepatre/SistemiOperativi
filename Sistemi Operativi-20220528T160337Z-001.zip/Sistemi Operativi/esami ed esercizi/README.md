# OpSy
Qualche esercizio svolto, l'assegnamento opzionale consegnato e qualche prova d'esame fatta. Codici non commentati o 
commentati parzialmente. Consiglio di guardare il file Tutorial.c che fornisce un'impostazione 
per la creazione di un server concorrente.
Materiale da prendere con le pinze come spunto per un primo approccio alla materia.
