#!/bin/bash
echo "VAR è: $VAR"
VAR="Ciao!"
echo "VAR è: $VAR"
