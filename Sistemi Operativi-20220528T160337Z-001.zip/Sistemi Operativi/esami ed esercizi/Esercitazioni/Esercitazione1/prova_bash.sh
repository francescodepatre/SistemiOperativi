#!/bin/bash
# Questo è un commento
# primo esercizio echo Hello World
loc2=hello
location=World
echo " ${loc2}  ${location}"


