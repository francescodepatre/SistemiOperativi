#include <stdio.h>
#include<math.h>

int main (){
double m,n;
m = 12345;
n = sqrt(m);
printf("The square root of %f is %f.\n", m,n);
return 0;
}
